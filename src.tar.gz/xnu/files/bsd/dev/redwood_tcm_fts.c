/*
 * Redmi 9 (M2004J19AG, lancelot, MT6768) touch screen driver for XNU.
 *
 * Controller: FocalTech fts_ts (cap_touch), I2C bus 0, address 0x14.
 * Input device in Android: input4, multitouch (PROP=2).
 *
 * This is a STUB. The FocalTech I2C protocol needs to be reverse-engineered
 * or taken from the Android kernel driver. Until then, this driver registers
 * /dev/redwood-touch but reports no touches.
 *
 * Android I2C devices found:
 *   0-0014  cap_touch   <- this is the touch controller (I2C bus 0, addr 0x14)
 *
 * What we know from Android:
 *   input4 name = "fts_ts", EV=b (multitouch), PROP=2
 *   ABS_MT_POSITION_X/Y, ABS_MT_TRACKING_ID present
 */

#include <kern/clock.h>
#include <kern/thread.h>
#include <libkern/libkern.h>
#include <mach/mach_types.h>
#include <pexpert/pexpert.h>
#include <sys/redwood_input.h>
#include <sys/systm.h>

#define FTS_I2C_ADDR   0x14
#define FTS_I2C_BUS    0

/* FocalTech register map — TO BE DETERMINED from Android driver or datasheet */
#define FTS_REG_DEVICE_ID      0x00   /* chip ID register (guess) */
#define FTS_REG_TOUCH_DATA     0x00   /* touch report start (guess) */
#define FTS_REG_CMD            0x00   /* command register (guess) */

static bool fts_ready = false;
static uint32_t fts_reports = 0, fts_touches = 0;

/* ---- I2C placeholder ---- */

/*
 * mtkloader already has I2C bit-banging? No — mtkloader uses SPI for the x6826b touch.
 * For Redmi 9 we need I2C access. Options:
 *   1. Bit-bang I2C through GPIO pins (need to find SDA/SCL GPIO numbers)
 *   2. Use the MT6768 I2C controller directly (registers at 0x1100xxxx)
 *   3. Read through Android's interface (not available in XNU)
 *
 * For now: all I2C functions return -1 (not implemented).
 */

static int fts_i2c_read(uint8_t reg, uint8_t *buf, int len)
{
    (void)reg; (void)buf; (void)len;
    return -1;   /* I2C not yet implemented */
}

static int fts_i2c_write(uint8_t reg, const uint8_t *buf, int len)
{
    (void)reg; (void)buf; (void)len;
    return -1;   /* I2C not yet implemented */
}

static int fts_init(void)
{
    uint8_t id = 0;
    int ret = fts_i2c_read(FTS_REG_DEVICE_ID, &id, 1);
    if (ret < 0) {
        printf("fts: I2C not implemented yet — touch disabled\n");
        return -1;
    }
    printf("fts: FocalTech touchscreen chip id=0x%02x on I2C-%d addr 0x%02x\n",
        id, FTS_I2C_BUS, FTS_I2C_ADDR);
    fts_ready = true;
    return 0;
}

static int fts_read_touch(int *x, int *y, int *id, int *pressure)
{
    *x = 0; *y = 0; *id = -1; *pressure = 0;
    return 0;   /* no touch */
}

/* ---- polling thread ---- */

static void
fts_thread(__unused void *parameter, __unused wait_result_t result)
{
    int x, y, tid, pressure;
    uint32_t poll_us = 8000;

    PE_parse_boot_argn("touch_poll_us", &poll_us, sizeof(poll_us));
    if (poll_us < 250 || poll_us > 100000) {
        poll_us = 8000;
    }

    printf("fts: polling FocalTech touch every %u us\n", poll_us);

    for (;;) {
        if (fts_ready && fts_read_touch(&x, &y, &tid, &pressure) == 0 && tid >= 0) {
            redwood_touch_post(REDWOOD_TOUCH_DOWN, (uint32_t)tid,
                (uint32_t)x * 65535 / 1080, (uint32_t)y * 65535 / 2340);
            fts_touches++;
        }
        fts_reports++;
        delay(poll_us);
    }
}

void
redwood_tcm_fts_init(void)
{
    uint32_t which = 0;
    thread_t thread;

    if (!PE_parse_boot_argn("touchscreen", &which, sizeof(which)) || which != 2) {
        return;
    }
    if (fts_init() != 0) {
        return;
    }
    if (kernel_thread_start(fts_thread, NULL, &thread) == KERN_SUCCESS) {
        thread_deallocate(thread);
    } else {
        printf("fts: cannot start touch polling thread\n");
    }
}