/*
 * redmi9.h — Redmi 9 (M2004J19AG, lancelot, MT6768) device constants for mtkloader.
 */

#ifndef REDMI9_H
#define REDMI9_H

#define REDMI9_XNUSYS_LBA      111536064ULL
#define REDMI9_XNUSYS_BLOCKS   10485760ULL

#define REDMI9_DISPLAY_WIDTH   1080
#define REDMI9_DISPLAY_HEIGHT  2340
#define REDMI9_DISPLAY_DPI     440

#define REDMI9_TOUCH_I2C_BUS   0
#define REDMI9_TOUCH_I2C_ADDR  0x14

#endif /* REDMI9_H */
